package com.jspiders.springmvcapp.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.jspiders.springmvcapp.pojo.BookPOJO;

@Repository
public class BookRepository 
{
	private static EntityManagerFactory factory;
	private static EntityManager manager;
	private static EntityTransaction transaction;
	private  static Query query;
	private static String jpql;
	
	public void openConnection()
	{
		factory=Persistence.createEntityManagerFactory("library");
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
	}
	public void closeConnection()
	{
		if(factory!=null)
		{
			factory.close();
		}
		if(manager!=null)
		{
			manager.close();
		}
		if(transaction.isActive())
		{
			transaction.rollback();
		}
	}
	public BookPOJO addBook(String name,String author,String publication,double price,int quantity)
	{
		openConnection();
		transaction.begin();
		BookPOJO book=new BookPOJO();
		book.setName(name);
		book.setAuthor(author);
		book.setPublication(publication);
		book.setPrice(price);
		book.setQuantity(quantity);
		manager.persist(book);
		transaction.commit();
		closeConnection();
		return book;
		
	}
	
	public BookPOJO searchBook(int id)
	{
		openConnection();
		transaction.begin();
		BookPOJO book=manager.find(BookPOJO.class, id);
		transaction.commit();
		closeConnection();
		return book;	
	}
	public List<BookPOJO> searchAllBooks()
	{
		openConnection();
		transaction.begin();
		jpql="from BookPOJO";
		query=manager.createQuery(jpql);
		List<BookPOJO> books=query.getResultList();
		transaction.commit();
		closeConnection();
		return  books;	
	}
	public void removeBook(int id)
	{
		openConnection();
		transaction.begin();
		BookPOJO book=manager.find(BookPOJO.class,id);
		manager.remove(book);
		transaction.commit();
		closeConnection();
	}
	public BookPOJO updateBook(int id,String name,String author,String publication,double price,int quantity)
	{
		openConnection();
		transaction.begin();
		BookPOJO book=manager.find(BookPOJO.class,id);
		book.setName(name);
		book.setAuthor(author);
		book.setPublication(publication);
		book.setPrice(price);
		book.setQuantity(quantity);
		manager.persist(book);
		transaction.commit();
		closeConnection();
		return book;	
	}

}
