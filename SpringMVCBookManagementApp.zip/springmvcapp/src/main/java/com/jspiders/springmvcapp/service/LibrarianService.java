package com.jspiders.springmvcapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.springmvcapp.pojo.LibrarianPOJO;
import com.jspiders.springmvcapp.repository.LibrarianRepository;

@Service
public class LibrarianService 
{
	@Autowired
	private LibrarianRepository repository;
	
	public LibrarianPOJO login(String username,String password)
	{
		LibrarianPOJO librarian=repository.login(username, password);
		return librarian ;
		
	}
	public LibrarianPOJO addLibrarian(String username,String password)
	{
		LibrarianPOJO librarian=repository.addLibrarian(username, password);
		return librarian;
	}

}
